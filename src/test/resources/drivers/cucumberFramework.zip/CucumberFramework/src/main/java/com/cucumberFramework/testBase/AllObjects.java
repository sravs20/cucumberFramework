package com.cucumberFramework.testBase;

import com.cucumberFramework.pageObjects.HomePage;

public interface AllObjects {

	static HomePage homePage = new HomePage(TestBase.driver);
}
