package com.cucumberFramework.pageObjects;

import com.cucumberFramework.helper.LoggerHelper;
import com.cucumberFramework.stepdefinitions.CheckoutPodPointStepDefination;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cucumberFramework.helper.Constants;
import com.cucumberFramework.helper.WaitHelper;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.List;

public class HomePage {
	Logger log = LoggerHelper.getLogger(HomePage.class);

	private WebDriver driver;

	WaitHelper waitHelper;

	@FindBy(xpath = "//*[@id='carMakeAndModel']/div/h2")
	public WebElement lblSelectYourCar;

	@FindBy(id = "vehicleBrand")
	public WebElement dropdownCarMake;

	@FindBy(id = "vehicleId")
	public WebElement dropdownCarModel;

	@FindBy(id = "optOut")
	public WebElement optoutCheckbox;

	@FindBy(xpath = "//h4[text()='Universal Socket']")
	public WebElement universalSocket;

	@FindBy(xpath = "//h4[text()='7kW']//following::span[1]")
	public WebElement sevenkwFullPriceValue;

	@FindBy(xpath = "//h4[text()='7kW']//following::span[3]")
	public WebElement sevenkwWithOLEVGrantValue;

	@FindBy(xpath = "//h2[text()='Compatible extras']")
	public WebElement compatibleExtrasSection;

	@FindBy(xpath = "//h4[text()='7kW']")
	public WebElement sevenkwsection;

	@FindAll(value={@FindBy(xpath="//section[@id='optionalExtras']//label//h4")})
	public List<WebElement> compExtras;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		waitHelper = new WaitHelper(driver);
	}

	public void selectModel(String model) {
		Select select = new Select(dropdownCarModel);
		select.selectByVisibleText(model);
		log.info("Selected: "+model);
	}

	public void selectMake(String make) {
		Select select = new Select(dropdownCarMake);
		select.selectByVisibleText(make);
		log.info("Selected: "+make);
	}

	public void selectOptOutCheckbox() throws InterruptedException {
		Thread.sleep(5000);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", optoutCheckbox);
	}

	public void selectUniversalSocket() throws InterruptedException {
		Thread.sleep(10000);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", universalSocket);
	}

	public void verify7kwfullPrice(String sevenkwfullprice) {
		waitHelper.WaitForElement(sevenkwFullPriceValue,30);
		Assert.assertTrue(sevenkwFullPriceValue.getText().trim().contains(sevenkwfullprice),
				"7KW full price Mismatch");
		log.info("7kw full price Matched");
	}

	public void verify7kwOLEVGrantPrice(String sevenkwOLEVGrantprice) {
		Assert.assertTrue(sevenkwWithOLEVGrantValue.getText().trim().contains(sevenkwOLEVGrantprice),
				"7kw Oleg Grant price Mismatch");
		log.info("7kw Oleg Grant price Matched");
	}

	public void verifycompatibleExtrasDisplayed(String extras) throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", sevenkwsection);
		Thread.sleep(5000);
		waitHelper.WaitForElement(compatibleExtrasSection,30);
//		List<WebElement> compExtras=driver.findElements(By.xpath("//section[@id='optionalExtras']//label//h4"));
		int extrass=Integer.valueOf(extras);
		Assert.assertEquals(compExtras.size(),extrass);
		log.info("6 Compatible extras are displayed");
		for(int i=0;i<compExtras.size();i++){
			log.info("compatibleExtras: "+compExtras.get(i).getText());
		}
	}

	public void selectCompatibleExtra() {
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", compExtras.get(1));
		log.info("Selected "+compExtras.get(1).getText());
	}
}
