package com.cucumberFramework.stepdefinitions;

import com.cucumberFramework.pageObjects.HomePage;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import org.apache.log4j.Logger;
import com.cucumberFramework.helper.LoggerHelper;
import com.cucumberFramework.helper.WaitHelper;
import com.cucumberFramework.testBase.TestBase;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CheckoutPodPointStepDefination extends TestBase {

	WaitHelper waitHelper = new WaitHelper(driver);
	HomePage homePage = new HomePage(driver);
	Logger log = LoggerHelper.getLogger(CheckoutPodPointStepDefination.class);

	@Given("^I am on page \"([^\"]*)\"$")
	public void iAmOnPage(String url) throws Throwable {
		driver.get(url);
		waitHelper.WaitForElement(homePage.lblSelectYourCar, 60);
	}

	@When("^I select make as \"([^\"]*)\" and model as \"([^\"]*)\" in the Select Your Car fields$")
	public void iSelectMakeAsAndModelAsInTheSelectYourCarFields(String make, String model) throws Throwable {
		homePage.selectMake(make);
		homePage.selectModel(model);
	}

	@When("^I check the checkbox \"([^\"]*)\"$")
	public void i_check_the_box(String arg1) throws Throwable {
		homePage.selectOptOutCheckbox();
	}

	@When("^I select the \"([^\"]*)\" option under Select your connection type$")
	public void i_select_the_option_under_Select_your_connection_type(String arg1) throws Throwable {
		homePage.selectUniversalSocket();
	}

	@Then("^I check the prices for the \"([^\"]*)\" unit displayed under Select your power rating match Full Price – \"([^\"]*)\"$")
	public void i_check_the_prices_for_the_unit_displayed_under_Select_your_power_rating_match_Full_Price(String arg1, String sevenkwfullprice) throws Throwable {
		homePage.verify7kwfullPrice(sevenkwfullprice);
	}

	@Then("^I check that \"([^\"]*)\" compatible extras are shown$")
	public void i_check_that_compatible_extras_are_shown(String extras) throws Throwable {
		homePage.verifycompatibleExtrasDisplayed(extras);
	}

	@When("^I select a random compatible extra$")
	public void i_select_a_random_compatible_extra() throws Throwable {
		homePage.selectCompatibleExtra();
	}

	@Then("^I ensure that the total price at the bottom right of the screen correctly matches the \"([^\"]*)\" unit price plus the compatible extra price$")
	public void i_ensure_that_the_total_price_at_the_bottom_right_of_the_screen_correctly_matches_the_unit_price_plus_the_compatible_extra_price(String arg1) throws Throwable {

	}

	@And("^I check the prices for the \"([^\"]*)\" unit displayed under Select your power rating match With OLEV Grant - \"([^\"]*)\"$")
	public void iCheckThePricesForTheUnitDisplayedUnderSelectYourPowerRatingMatchWithOLEVGrant(String arg0, String sevenkwOLEVGrantprice) throws Throwable {
		homePage.verify7kwOLEVGrantPrice(sevenkwOLEVGrantprice);
	}
}
