Execution Steps:

To execute the test cases, follow the below steps:
1. Clone the project
2. Open project in any IDE
3. Execute TestRunner file in src>main>java>testRunner
or execute testng.xml file in the project folder
4. To execute from command prompt, use >mvn test
5. To view the results, Navigate to target/cucumber-reports/cucumber-pretty/index.html
